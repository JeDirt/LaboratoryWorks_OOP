package com.company;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;


public class TicTacToe
{


    TicTacToe()
    {

        FillGameBoard();
        this.CurrentPlayer = false;

    }


    // Launch game cycle
    public void LaunchGame()
    {
        MakeMove();
    }

    // Outputs board to the console
    private void PrintGameBoard()
    {

        for(char[] row : GameBoard)
        {

            for (char c : row)
            {
                System.out.print(c);
            }

            System.out.println();

        }

    }

    // Assign board for the start
    private void FillGameBoard()
    {

        GameBoard = new char[][]
                {
                        {' ',' ','|',' ',' ','|', ' '},
                        {'—','—','+','—','—','+','—','—'},
                        {' ',' ','|',' ',' ','|', ' '},
                        {'—','—','+','—','—','+','—','—'},
                        {' ',' ','|',' ',' ','|', ' '},
                };

    }

    // Imitate switching between players(moves)
    private void MakeMove()
    {

        // Variable to switch between players, saves previous player index to decide which is next
        boolean PreviousPlayer = true;

        do
        {


            // Check if we should switch between players
            if(!PreviousPlayer){CurrentPlayer = true;}
            else{ CurrentPlayer = false;}


            // Depending on CurrentPlayer choose the symbol to input
            char CurrentSymbol = CurrentPlayer ? '0' : 'X';
            PrintGameBoard();


            // Get player's input
            Scanner Input = new Scanner(System.in);

            System.out.printf("Choose the position of your element, my Lord %s (1 to 9):",CurrentSymbol);
            int SymbolPosition = Input.nextInt();


            // Keep input until player reach correct place
            while(X_PlayerPositions.contains(SymbolPosition) || O_PlayerPositions.contains(X_PlayerPositions))
            {

                System.out.println("Position is already taken, play rules, little ass! Try again:");
                SymbolPosition = Input.nextInt();

            }


            // Fill matrix' field by user's input index
            switch (SymbolPosition)
            {

                case 1:
                {
                    GameBoard[0][1] = CurrentSymbol;
                    break;
                }

                case 2:
                {
                    GameBoard[0][3] = CurrentSymbol;
                    break;
                }

                case 3:
                {
                    GameBoard[0][6] = CurrentSymbol;
                    break;
                }

                case 4:
                {
                    GameBoard[2][1] = CurrentSymbol;
                    break;
                }

                case 5:
                {
                    GameBoard[2][3] = CurrentSymbol;
                    break;
                }

                case 6:
                {
                    GameBoard[2][6] = CurrentSymbol;
                    break;
                }

                case 7:
                {
                    GameBoard[4][1] = CurrentSymbol;
                    break;
                }

                case 8:
                {
                    GameBoard[4][3] = CurrentSymbol;
                    break;
                }

                case 9:
                {
                    GameBoard[4][6] = CurrentSymbol;
                    break;
                }

                default:
                    break;

            }


            // Fill lists of filled fields of every player to check combinations of won
            if(CurrentPlayer){ O_PlayerPositions.add(SymbolPosition);}
            else{ X_PlayerPositions.add(SymbolPosition);}


            // Check if we have any won combination
            if(isWon())
            {

                PrintGameBoard();

                System.out.printf("You've won! %s",CurrentSymbol);
                break;

            }


            // Remember current player to switch it next iteration
            PreviousPlayer = CurrentPlayer;


        }while(true);

    }

    // Check if we have any won combination to stop game
    private boolean isWon()
    {

        // Assign all won combinations
        List topRow = Arrays.asList(1,2,3);
        List midRow = Arrays.asList(4,5,6);
        List bottomRow = Arrays.asList(7,8,9);

        List leftColumn = Arrays.asList(1,4,7);
        List midColumn = Arrays.asList(2,5,8);
        List rightColumn = Arrays.asList(3,6,9);

        List diagonal1 = Arrays.asList(1,5,9);
        List diagonal2 = Arrays.asList(7,5,3);


        // Create List for all these combinations and push it in
        List<List>SuccessfulCombinations = new ArrayList<List>();

        SuccessfulCombinations.add(topRow);
        SuccessfulCombinations.add(midRow);
        SuccessfulCombinations.add(rightColumn);

        SuccessfulCombinations.add(leftColumn);
        SuccessfulCombinations.add(midColumn);
        SuccessfulCombinations.add(rightColumn);

        SuccessfulCombinations.add(diagonal1);
        SuccessfulCombinations.add(diagonal2);


        // Check if any player has won combination
        for(List el : SuccessfulCombinations)
        {

            // If anyone has, return true, loop will stop
            if(X_PlayerPositions.containsAll(el) || O_PlayerPositions.containsAll(el))
            {
                return true;
            }

        }

        return false;

    }




    private char[][]GameBoard;

    // If false - X, true - 0
    private boolean CurrentPlayer;

    // Array lists to store current filled fields of every player
    static ArrayList<Integer> X_PlayerPositions = new ArrayList<Integer>();
    static ArrayList<Integer> O_PlayerPositions = new ArrayList<Integer>();

}
